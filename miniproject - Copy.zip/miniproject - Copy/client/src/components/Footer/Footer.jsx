import React from "react";

const Footer = () => (
  <footer>
    <p>Footer</p>
  </footer>
);

export default Footer;

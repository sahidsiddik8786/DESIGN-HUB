import React from "react";

const HelloWorld = () => <p>Hello World</p>;

export default HelloWorld;

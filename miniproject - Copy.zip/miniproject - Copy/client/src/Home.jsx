// Import React and CSS modules
import React from 'react';
import './App.css';

// Functional component for the homepage
function HomePage() {
  return (
    <div className="homepage">
      <header className="header">
        <nav className="navbar">
          <div className="logo">
            <h1>Your Interior Designs</h1>
          </div>
          <ul className="nav-links">
            <li><a href="/">Home</a></li>
            <li><a href="/portfolio">Portfolio</a></li>
            <li><a href="/services">Services</a></li>
            <li><a href="/contact">Contact</a></li>
          </ul>
        </nav>
      </header>

      <section className="hero">
        <div className="hero-content">
          <h2>Welcome to Your Dream Space</h2>
          <p>Elevate your living experience with our exquisite interior designs.</p>
          <a href="/portfolio" className="cta-button">View Portfolio</a>
        </div>
      </section>

      <section className="about">
        <div className="about-content">
          <h3>About Us</h3>
          <p>We are a passionate team of interior designers dedicated to transforming your spaces into works of art.</p>
          <a href="/about" className="cta-button">Learn More</a>
        </div>
      </section>

      <section className="contact">
        <div className="contact-content">
          <h3>Contact Us</h3>
          <p>Ready to get started? Contact us today to discuss your project.</p>
          <a href="/contact" className="cta-button">Contact Now</a>
        </div>
      </section>

      <footer className="footer">
        <p>&copy; {new Date().getFullYear()} Your Interior Designs</p>
      </footer>
    </div>
  );
}

export default HomePage;
